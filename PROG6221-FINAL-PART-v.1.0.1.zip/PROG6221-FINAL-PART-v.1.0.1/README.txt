The name of this Program is Cyber Security Chatbot

This is a system that the user can use to chat with a chatbot about Security related matters. You can easily run the Program using visual studio 2022.
The Program is connected to a working sql database that will save tyhe activities done using the chatbot. You can do a lot of things in this system like have a chat with a chatbot, play a quiz game, add tasks, view tasks and delete tasks.
The quiz is easily accessible by click the section that says quiz or asking the chatbot.
If you want to check what you have been doing in the chatbot you can access the activity log where it says activity log to view all the activities being done using the chatbot

  
