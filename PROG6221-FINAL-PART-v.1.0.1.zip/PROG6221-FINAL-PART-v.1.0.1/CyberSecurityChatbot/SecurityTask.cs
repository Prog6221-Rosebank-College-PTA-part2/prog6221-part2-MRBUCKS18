using System;

namespace CyberSecurityChatbotWinForms
{
    public class SecurityTask
    {
        public int Id { get; set; }
        public string Title { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public DateTime? ReminderDate { get; set; }
        public bool IsCompleted { get; set; }
        public DateTime CreatedAt { get; set; } = DateTime.Now;

        public string ReminderDisplay => ReminderDate.HasValue ? ReminderDate.Value.ToString("yyyy-MM-dd") : "No reminder";
        public string StatusDisplay => IsCompleted ? "Completed" : "Pending";
    }
}
