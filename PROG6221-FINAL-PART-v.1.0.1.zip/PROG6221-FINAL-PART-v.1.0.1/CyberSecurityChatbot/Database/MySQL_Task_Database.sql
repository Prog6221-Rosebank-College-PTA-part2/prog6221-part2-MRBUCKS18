-- MySQL database script for the Cyber Security Chatbot Task Assistant
-- Use this in MySQL Workbench/phpMyAdmin if your lecturer asks to show the database design.

CREATE DATABASE IF NOT EXISTS cyber_security_chatbot;
USE cyber_security_chatbot;

CREATE TABLE IF NOT EXISTS cybersecurity_tasks (
    task_id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(150) NOT NULL,
    description VARCHAR(500) NOT NULL,
    reminder_date DATE NULL,
    is_completed BOOLEAN NOT NULL DEFAULT FALSE,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS activity_log (
    log_id INT AUTO_INCREMENT PRIMARY KEY,
    action_description VARCHAR(500) NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);
