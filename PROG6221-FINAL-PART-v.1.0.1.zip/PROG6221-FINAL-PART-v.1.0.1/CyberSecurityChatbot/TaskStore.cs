using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;

namespace CyberSecurityChatbotWinForms
{
    public class TaskStore
    {
        private readonly string _filePath;
        private readonly List<SecurityTask> _tasks;

        public TaskStore()
        {
            string folder = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Database");
            Directory.CreateDirectory(folder);
            _filePath = Path.Combine(folder, "tasks_db.json");
            _tasks = LoadTasks();
        }

        public List<SecurityTask> GetAll()
        {
            return _tasks.OrderBy(t => t.IsCompleted).ThenBy(t => t.ReminderDate ?? DateTime.MaxValue).ThenBy(t => t.Id).ToList();
        }

        public SecurityTask Add(string title, string description, DateTime? reminderDate)
        {
            int nextId = _tasks.Count == 0 ? 1 : _tasks.Max(t => t.Id) + 1;
            var task = new SecurityTask
            {
                Id = nextId,
                Title = title.Trim(),
                Description = description.Trim(),
                ReminderDate = reminderDate,
                IsCompleted = false,
                CreatedAt = DateTime.Now
            };
            _tasks.Add(task);
            Save();
            return task;
        }

        public void MarkCompleted(int id)
        {
            var task = _tasks.FirstOrDefault(t => t.Id == id);
            if (task != null)
            {
                task.IsCompleted = true;
                Save();
            }
        }

        public void Delete(int id)
        {
            var task = _tasks.FirstOrDefault(t => t.Id == id);
            if (task != null)
            {
                _tasks.Remove(task);
                Save();
            }
        }

        private List<SecurityTask> LoadTasks()
        {
            try
            {
                if (!File.Exists(_filePath))
                    return new List<SecurityTask>();

                string json = File.ReadAllText(_filePath);
                return JsonSerializer.Deserialize<List<SecurityTask>>(json) ?? new List<SecurityTask>();
            }
            catch
            {
                return new List<SecurityTask>();
            }
        }

        private void Save()
        {
            var options = new JsonSerializerOptions { WriteIndented = true };
            File.WriteAllText(_filePath, JsonSerializer.Serialize(_tasks, options));
        }
    }
}
