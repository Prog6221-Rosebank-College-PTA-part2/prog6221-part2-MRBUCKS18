using System;
using System.Collections.Generic;
using System.IO;

namespace CyberSecurityChatbotWinForms
{
    public class ActivityLogger
    {
        private readonly string _filePath;

        public ActivityLogger()
        {
            string folder = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Database");
            Directory.CreateDirectory(folder);
            _filePath = Path.Combine(folder, "activity_log.txt");
        }

        public void Add(string action)
        {
            string line = $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] {action}";
            File.AppendAllLines(_filePath, new[] { line });
        }

        public List<string> ReadAll()
        {
            if (!File.Exists(_filePath))
                return new List<string>();
            return new List<string>(File.ReadAllLines(_filePath));
        }

        public void Clear()
        {
            File.WriteAllText(_filePath, string.Empty);
        }
    }
}
