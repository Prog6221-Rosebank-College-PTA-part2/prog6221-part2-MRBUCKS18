using System.Collections.Generic;

namespace CyberSecurityChatbotWinForms
{
    public class QuizEngine
    {
        private readonly List<QuizQuestion> _questions = new List<QuizQuestion>
        {
            new QuizQuestion { Question = "What should you do if you receive an email asking for your password?", Options = new List<string>{ "Reply with your password", "Delete the email only", "Report the email as phishing", "Ignore it" }, CorrectIndex = 2, Explanation = "Correct action is to report it as phishing because legitimate companies should not ask for your password by email." },
            new QuizQuestion { Question = "A strong password should be unique for each account.", Options = new List<string>{ "True", "False" }, CorrectIndex = 0, IsTrueFalse = true, Explanation = "Using unique passwords protects your other accounts if one password is leaked." },
            new QuizQuestion { Question = "Which option is safest for two-factor authentication?", Options = new List<string>{ "Sharing your login code", "Using an authenticator app", "Writing codes on public notes", "Turning it off" }, CorrectIndex = 1, Explanation = "An authenticator app adds an extra layer of protection beyond the password." },
            new QuizQuestion { Question = "What does HTTPS usually indicate on a website?", Options = new List<string>{ "The site is encrypted", "The site is always safe", "The site is fake", "The site needs no password" }, CorrectIndex = 0, Explanation = "HTTPS means the connection is encrypted, but you should still check if the website is trustworthy." },
            new QuizQuestion { Question = "Phishing messages often use urgent language to pressure users.", Options = new List<string>{ "True", "False" }, CorrectIndex = 0, IsTrueFalse = true, Explanation = "Scammers often create urgency to make people click links without thinking." },
            new QuizQuestion { Question = "Which information should you avoid posting publicly online?", Options = new List<string>{ "Favourite movie", "Personal address", "General hobby", "Weather comment" }, CorrectIndex = 1, Explanation = "Your personal address can put your privacy and safety at risk." },
            new QuizQuestion { Question = "What should you do before downloading software?", Options = new List<string>{ "Download from any pop-up", "Check that the source is trusted", "Disable antivirus", "Ignore warnings" }, CorrectIndex = 1, Explanation = "Trusted sources reduce the risk of malware infection." },
            new QuizQuestion { Question = "A link that looks shortened can hide the real website address.", Options = new List<string>{ "True", "False" }, CorrectIndex = 0, IsTrueFalse = true, Explanation = "Short links can hide the destination, so you should be careful before opening them." },
            new QuizQuestion { Question = "Social engineering is when attackers manipulate people into giving information.", Options = new List<string>{ "True", "False" }, CorrectIndex = 0, IsTrueFalse = true, Explanation = "Social engineering targets human trust rather than only technical weaknesses." },
            new QuizQuestion { Question = "Which is a sign of a possible scam?", Options = new List<string>{ "A normal receipt", "Urgent request for money or personal details", "A known school email", "A saved contact" }, CorrectIndex = 1, Explanation = "Urgent requests for money or personal information are common scam warning signs." },
            new QuizQuestion { Question = "What should you do if you are unsure about a suspicious message?", Options = new List<string>{ "Click quickly", "Ask the sender to prove it through the same suspicious link", "Verify using an official contact method", "Forward it to everyone" }, CorrectIndex = 2, Explanation = "Use official contact details, not the suspicious message, to verify the request." },
            new QuizQuestion { Question = "It is safe to use the same password for all accounts if it is easy to remember.", Options = new List<string>{ "True", "False" }, CorrectIndex = 1, IsTrueFalse = true, Explanation = "Reusing passwords is dangerous because one leak can expose many accounts." }
        };

        public int CurrentIndex { get; private set; }
        public int Score { get; private set; }
        public bool IsRunning { get; private set; }
        public int TotalQuestions => _questions.Count;
        public QuizQuestion? CurrentQuestion => IsRunning && CurrentIndex < _questions.Count ? _questions[CurrentIndex] : null;

        public void Start()
        {
            CurrentIndex = 0;
            Score = 0;
            IsRunning = true;
        }

        public string SubmitAnswer(int selectedIndex)
        {
            if (!IsRunning || CurrentQuestion == null)
                return "Start the quiz first.";

            bool correct = selectedIndex == CurrentQuestion.CorrectIndex;
            if (correct)
                Score++;

            string feedback = correct ? "Correct! " : "Incorrect. ";
            feedback += CurrentQuestion.Explanation;

            CurrentIndex++;
            if (CurrentIndex >= _questions.Count)
            {
                IsRunning = false;
                feedback += $"\n\nQuiz completed. Final score: {Score}/{TotalQuestions}. ";
                feedback += Score >= 9 ? "Great job! You're a cybersecurity pro!" : "Keep learning to stay safe online!";
            }

            return feedback;
        }
    }
}
