namespace CyberSecurityChatbotWinForms
{
    public class User
    {
        public string Name { get; set; } = "Friend";
    }
}
