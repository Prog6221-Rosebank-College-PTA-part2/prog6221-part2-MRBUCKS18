using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace CyberSecurityChatbotWinForms
{
    public class MainForm : Form
    {
        private readonly ChatbotEngine _chatbot = new ChatbotEngine();
        private readonly TaskStore _taskStore = new TaskStore();
        private readonly QuizEngine _quizEngine = new QuizEngine();
        private readonly ActivityLogger _logger = new ActivityLogger();

        private bool _chatStarted = false;
        private string _userName = "Friend";

        private Label logoLabel = new Label();
        private TextBox nameTextBox = new TextBox();
        private Button startButton = new Button();
        private RichTextBox chatBox = new RichTextBox();
        private TextBox questionTextBox = new TextBox();
        private Button sendButton = new Button();
        private Button clearButton = new Button();
        private Button exitButton = new Button();
        private Button helpButton = new Button();
        private Button passwordButton = new Button();
        private Button phishingButton = new Button();
        private Button scamButton = new Button();
        private Button taskShortcutButton = new Button();
        private Button quizShortcutButton = new Button();

        private TextBox taskTitleTextBox = new TextBox();
        private TextBox taskDescriptionTextBox = new TextBox();
        private DateTimePicker reminderPicker = new DateTimePicker();
        private CheckBox reminderCheckBox = new CheckBox();
        private DataGridView taskGrid = new DataGridView();

        private Label quizQuestionLabel = new Label();
        private RadioButton optionA = new RadioButton();
        private RadioButton optionB = new RadioButton();
        private RadioButton optionC = new RadioButton();
        private RadioButton optionD = new RadioButton();
        private Label quizProgressLabel = new Label();
        private RichTextBox quizFeedbackBox = new RichTextBox();
        private Button startQuizButton = new Button();
        private Button submitQuizButton = new Button();

        private RichTextBox activityLogBox = new RichTextBox();

        private const string AsciiLogo = @"   ____  __   __ ____  _____ ____      ____  _____ ____ _   _ ____  ___ _______   __
  / ___| \ \ / /| __ )| ____|  _ \    / ___|| ____/ ___| | | |  _ \|_ _|_   _\ \ / /
 | |      \ V / |  _ \|  _| | |_) |   \___ \|  _|| |   | | | | |_) || |  | |  \ V / 
 | |___    | |  | |_) | |___|  _ <     ___) | |__| |___| |_| |  _ < | |  | |   | |  
  \____|   |_|  |____/|_____|_| \_\   |____/|_____\____|\___/|_| \_\___| |_|   |_|  ";

        public MainForm()
        {
            Text = "Cyber Security Chatbot";
            StartPosition = FormStartPosition.CenterScreen;
            MinimumSize = new Size(1120, 780);
            BackColor = Color.FromArgb(18, 24, 38);
            ForeColor = Color.White;
            Font = new Font("Segoe UI", 10F);

            BuildInterface();
            RefreshTaskGrid(GetTaskGrid());
            RefreshActivityLog();
            _logger.Add("Application launched");
            RefreshActivityLog();

            Shown += MainForm_Shown;
        }

        private void MainForm_Shown(object? sender, EventArgs e)
        {
            AudioPlayer.PlayGreeting();
        }

        private void BuildInterface()
        {
            var mainPanel = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 1,
                RowCount = 3,
                Padding = new Padding(18),
                BackColor = Color.FromArgb(18, 24, 38)
            };
            mainPanel.RowStyles.Add(new RowStyle(SizeType.Absolute, 115));
            mainPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            mainPanel.RowStyles.Add(new RowStyle(SizeType.Absolute, 42));
            Controls.Add(mainPanel);

            logoLabel = new Label
            {
                Text = AsciiLogo,
                Dock = DockStyle.Fill,
                Font = new Font("Consolas", 9.2F, FontStyle.Bold),
                ForeColor = Color.FromArgb(78, 219, 255),
                BackColor = Color.FromArgb(9, 14, 26),
                TextAlign = ContentAlignment.MiddleCenter,
                AutoSize = false,
                BorderStyle = BorderStyle.FixedSingle
            };
            mainPanel.Controls.Add(logoLabel, 0, 0);

            var tabs = new TabControl
            {
                Dock = DockStyle.Fill,
                Font = new Font("Segoe UI", 10F, FontStyle.Bold)
            };
            mainPanel.Controls.Add(tabs, 0, 1);

            tabs.TabPages.Add(BuildChatTab());
            tabs.TabPages.Add(BuildTaskTab());
            tabs.TabPages.Add(BuildQuizTab());
            tabs.TabPages.Add(BuildLogTab());

            var footer = new Label
            {
                Text = "Part 3 Features: Task Assistant, Cybersecurity Quiz, NLP Simulation, Activity Log, Memory, Sentiment Detection, Keyword Recognition, and Error Handling.",
                Dock = DockStyle.Fill,
                ForeColor = Color.LightGray,
                TextAlign = ContentAlignment.MiddleCenter
            };
            mainPanel.Controls.Add(footer, 0, 2);
        }

        private TabPage BuildChatTab()
        {
            var page = new TabPage("Chatbot");
            page.BackColor = Color.FromArgb(18, 24, 38);
            var mainPanel = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 1,
                RowCount = 5,
                Padding = new Padding(12),
                BackColor = Color.FromArgb(18, 24, 38)
            };
            mainPanel.RowStyles.Add(new RowStyle(SizeType.Absolute, 55));
            mainPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            mainPanel.RowStyles.Add(new RowStyle(SizeType.Absolute, 55));
            mainPanel.RowStyles.Add(new RowStyle(SizeType.Absolute, 52));
            mainPanel.RowStyles.Add(new RowStyle(SizeType.Absolute, 40));
            page.Controls.Add(mainPanel);

            var namePanel = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.LeftToRight, BackColor = Color.FromArgb(18, 24, 38), Padding = new Padding(0, 10, 0, 0) };
            mainPanel.Controls.Add(namePanel, 0, 0);
            namePanel.Controls.Add(new Label { Text = "Enter your name:", ForeColor = Color.White, Width = 125, Height = 30, TextAlign = ContentAlignment.MiddleLeft });
            nameTextBox = new TextBox { Width = 250, Height = 30, Font = new Font("Segoe UI", 10F) };
            nameTextBox.KeyDown += (s, e) => { if (e.KeyCode == Keys.Enter) StartChat(); };
            namePanel.Controls.Add(nameTextBox);
            startButton = CreateButton("Start Chat", 120);
            startButton.Click += (s, e) => StartChat();
            namePanel.Controls.Add(startButton);

            chatBox = new RichTextBox
            {
                Dock = DockStyle.Fill,
                ReadOnly = true,
                BackColor = Color.FromArgb(245, 248, 252),
                ForeColor = Color.FromArgb(25, 25, 25),
                Font = new Font("Segoe UI", 10.5F),
                BorderStyle = BorderStyle.FixedSingle,
                HideSelection = false
            };
            mainPanel.Controls.Add(chatBox, 0, 1);
            AddBotMessage("Welcome! The voice greeting will play automatically when the program launches. Enter your name and click Start Chat.");

            var questionPanel = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, BackColor = Color.FromArgb(18, 24, 38), Padding = new Padding(0, 10, 0, 0) };
            questionPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            questionPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 120));
            mainPanel.Controls.Add(questionPanel, 0, 2);

            questionTextBox = new TextBox { Dock = DockStyle.Fill, Enabled = false, Font = new Font("Segoe UI", 11F) };
            questionTextBox.KeyDown += (s, e) => { if (e.KeyCode == Keys.Enter) SendQuestion(); };
            questionPanel.Controls.Add(questionTextBox, 0, 0);
            sendButton = CreateButton("Send", 100);
            sendButton.Dock = DockStyle.Fill;
            sendButton.Enabled = false;
            sendButton.Click += (s, e) => SendQuestion();
            questionPanel.Controls.Add(sendButton, 1, 0);

            var examplesPanel = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.LeftToRight, BackColor = Color.FromArgb(18, 24, 38), Padding = new Padding(0, 8, 0, 0) };
            mainPanel.Controls.Add(examplesPanel, 0, 3);
            helpButton = CreateButton("Help", 95); helpButton.Click += (s, e) => FillExample("What can I ask you about?"); examplesPanel.Controls.Add(helpButton);
            passwordButton = CreateButton("Password Tip", 130); passwordButton.Click += (s, e) => FillExample("Tell me about password safety"); examplesPanel.Controls.Add(passwordButton);
            phishingButton = CreateButton("Phishing Tip", 130); phishingButton.Click += (s, e) => FillExample("Give me a phishing tip"); examplesPanel.Controls.Add(phishingButton);
            scamButton = CreateButton("Scam Help", 115); scamButton.Click += (s, e) => FillExample("I am worried about online scams"); examplesPanel.Controls.Add(scamButton);
            taskShortcutButton = CreateButton("Add Task", 105); taskShortcutButton.Click += (s, e) => FillExample("Add task - Review privacy settings"); examplesPanel.Controls.Add(taskShortcutButton);
            quizShortcutButton = CreateButton("Start Quiz", 105); quizShortcutButton.Click += (s, e) => FillExample("Start quiz"); examplesPanel.Controls.Add(quizShortcutButton);
            clearButton = CreateButton("Clear Chat", 115); clearButton.Click += (s, e) => ClearChat(); examplesPanel.Controls.Add(clearButton);
            exitButton = CreateButton("Exit", 85); exitButton.Click += (s, e) => Close(); examplesPanel.Controls.Add(exitButton);

            var info = new Label
            {
                Text = "NLP examples: 'Can you remind me to update my password?', 'Add a reminder to check privacy settings', 'Start quiz'.",
                Dock = DockStyle.Fill,
                ForeColor = Color.LightGray,
                TextAlign = ContentAlignment.MiddleLeft
            };
            mainPanel.Controls.Add(info, 0, 4);
            return page;
        }

        private TabPage BuildTaskTab()
        {
            var page = new TabPage("Task Assistant");
            page.BackColor = Color.FromArgb(18, 24, 38);
            var layout = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 3, Padding = new Padding(12), BackColor = Color.FromArgb(18, 24, 38) };
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 175));
            layout.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 48));
            page.Controls.Add(layout);

            var inputGroup = new GroupBox { Text = "Add Cybersecurity Task", Dock = DockStyle.Fill, ForeColor = Color.White, Font = new Font("Segoe UI", 10F, FontStyle.Bold) };
            layout.Controls.Add(inputGroup, 0, 0);
            var input = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 4, RowCount = 3, Padding = new Padding(10) };
            input.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 110));
            input.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
            input.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 130));
            input.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
            inputGroup.Controls.Add(input);

            input.Controls.Add(new Label { Text = "Title:", ForeColor = Color.White, Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft }, 0, 0);
            taskTitleTextBox = new TextBox { Dock = DockStyle.Fill, Font = new Font("Segoe UI", 10F) };
            input.Controls.Add(taskTitleTextBox, 1, 0);
            reminderCheckBox = new CheckBox { Text = "Use Reminder", ForeColor = Color.White, Dock = DockStyle.Fill, Checked = true };
            input.Controls.Add(reminderCheckBox, 2, 0);
            reminderPicker = new DateTimePicker { Dock = DockStyle.Fill, Format = DateTimePickerFormat.Short, Value = DateTime.Today.AddDays(3) };
            input.Controls.Add(reminderPicker, 3, 0);
            input.Controls.Add(new Label { Text = "Description:", ForeColor = Color.White, Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft }, 0, 1);
            taskDescriptionTextBox = new TextBox { Dock = DockStyle.Fill, Font = new Font("Segoe UI", 10F) };
            input.SetColumnSpan(taskDescriptionTextBox, 3);
            input.Controls.Add(taskDescriptionTextBox, 1, 1);

            var buttons = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.LeftToRight };
            input.SetColumnSpan(buttons, 4);
            input.Controls.Add(buttons, 0, 2);
            var addButton = CreateButton("Add Task", 115); addButton.Click += (s, e) => AddTaskFromForm(); buttons.Controls.Add(addButton);
            var exampleButton = CreateButton("Example 2FA", 125); exampleButton.Click += (s, e) => { taskTitleTextBox.Text = "Enable two-factor authentication"; taskDescriptionTextBox.Text = "Set up 2FA on important accounts to protect them from unauthorised access."; }; buttons.Controls.Add(exampleButton);
            var refreshButton = CreateButton("Refresh", 105); refreshButton.Click += (s, e) => RefreshTaskGrid(GetTaskGrid()); buttons.Controls.Add(refreshButton);

            taskGrid = new DataGridView { Dock = DockStyle.Fill, ReadOnly = true, SelectionMode = DataGridViewSelectionMode.FullRowSelect, MultiSelect = false, AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill, BackgroundColor = Color.White };
            layout.Controls.Add(taskGrid, 0, 1);

            var manageButtons = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.LeftToRight, BackColor = Color.FromArgb(18, 24, 38) };
            layout.Controls.Add(manageButtons, 0, 2);
            var completeButton = CreateButton("Mark Completed", 150); completeButton.Click += (s, e) => MarkSelectedTaskCompleted(); manageButtons.Controls.Add(completeButton);
            var deleteButton = CreateButton("Delete Task", 120); deleteButton.Click += (s, e) => DeleteSelectedTask(); manageButtons.Controls.Add(deleteButton);

            return page;
        }

        private TabPage BuildQuizTab()
        {
            var page = new TabPage("Mini Game Quiz");
            page.BackColor = Color.FromArgb(18, 24, 38);
            var layout = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 5, Padding = new Padding(18), BackColor = Color.FromArgb(18, 24, 38) };
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 44));
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 95));
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 150));
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 60));
            layout.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            page.Controls.Add(layout);

            quizProgressLabel = new Label { Text = "Click Start Quiz to begin.", Dock = DockStyle.Fill, ForeColor = Color.White, Font = new Font("Segoe UI", 11F, FontStyle.Bold), TextAlign = ContentAlignment.MiddleLeft };
            layout.Controls.Add(quizProgressLabel, 0, 0);
            quizQuestionLabel = new Label { Text = "The quiz contains more than 10 cybersecurity questions with multiple choice and true/false formats.", Dock = DockStyle.Fill, ForeColor = Color.White, Font = new Font("Segoe UI", 12F, FontStyle.Bold), TextAlign = ContentAlignment.MiddleLeft };
            layout.Controls.Add(quizQuestionLabel, 0, 1);

            var optionsPanel = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 4, BackColor = Color.FromArgb(18, 24, 38) };
            layout.Controls.Add(optionsPanel, 0, 2);
            optionA = CreateOption(); optionB = CreateOption(); optionC = CreateOption(); optionD = CreateOption();
            optionsPanel.Controls.Add(optionA, 0, 0); optionsPanel.Controls.Add(optionB, 0, 1); optionsPanel.Controls.Add(optionC, 0, 2); optionsPanel.Controls.Add(optionD, 0, 3);

            var quizButtons = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.LeftToRight, BackColor = Color.FromArgb(18, 24, 38) };
            layout.Controls.Add(quizButtons, 0, 3);
            startQuizButton = CreateButton("Start Quiz", 120); startQuizButton.Click += (s, e) => StartQuiz(); quizButtons.Controls.Add(startQuizButton);
            submitQuizButton = CreateButton("Submit Answer", 150); submitQuizButton.Enabled = false; submitQuizButton.Click += (s, e) => SubmitQuizAnswer(); quizButtons.Controls.Add(submitQuizButton);

            quizFeedbackBox = new RichTextBox { Dock = DockStyle.Fill, ReadOnly = true, BackColor = Color.FromArgb(245, 248, 252), ForeColor = Color.Black, Font = new Font("Segoe UI", 10.5F) };
            layout.Controls.Add(quizFeedbackBox, 0, 4);
            quizFeedbackBox.Text = "Immediate feedback will appear here after each answer. Your final score will be shown at the end.";

            SetQuizOptionsEnabled(false);
            return page;
        }

        private TabPage BuildLogTab()
        {
            var page = new TabPage("Activity Log");
            page.BackColor = Color.FromArgb(18, 24, 38);
            var layout = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 2, Padding = new Padding(12), BackColor = Color.FromArgb(18, 24, 38) };
            layout.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 50));
            page.Controls.Add(layout);

            activityLogBox = new RichTextBox { Dock = DockStyle.Fill, ReadOnly = true, BackColor = Color.FromArgb(245, 248, 252), ForeColor = Color.Black, Font = new Font("Consolas", 10F) };
            layout.Controls.Add(activityLogBox, 0, 0);

            var buttons = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.LeftToRight, BackColor = Color.FromArgb(18, 24, 38) };
            layout.Controls.Add(buttons, 0, 1);
            var refresh = CreateButton("Refresh Log", 130); refresh.Click += (s, e) => RefreshActivityLog(); buttons.Controls.Add(refresh);
            var clear = CreateButton("Clear Log", 120); clear.Click += (s, e) => { _logger.Clear(); RefreshActivityLog(); }; buttons.Controls.Add(clear);
            return page;
        }

        private Button CreateButton(string text, int width)
        {
            return new Button { Text = text, Width = width, Height = 34, BackColor = Color.FromArgb(37, 99, 235), ForeColor = Color.White, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9.5F, FontStyle.Bold), Margin = new Padding(5) };
        }

        private RadioButton CreateOption()
        {
            return new RadioButton { Dock = DockStyle.Fill, ForeColor = Color.White, Font = new Font("Segoe UI", 10.5F), AutoSize = false };
        }

        private void StartChat()
        {
            string name = nameTextBox.Text.Trim();
            if (string.IsNullOrWhiteSpace(name))
            {
                MessageBox.Show("Name cannot be empty. Please enter your name.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                nameTextBox.Focus();
                return;
            }

            _userName = FormatName(name);
            _chatStarted = true;
            questionTextBox.Enabled = true;
            sendButton.Enabled = true;
            questionTextBox.Focus();

            chatBox.Clear();
            AddBotMessage($"Hello {_userName}! Welcome to the Cyber Security Chatbot.");
            AddBotMessage("You can ask about passwords, scams, privacy, phishing, safe browsing, suspicious links, malware, tasks, reminders, and the quiz.");
            _logger.Add($"Chat started for {_userName}");
            RefreshActivityLog();
        }

        private void SendQuestion()
        {
            if (!_chatStarted)
            {
                MessageBox.Show("Please enter your name and click Start Chat first.", "Start Required", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            string question = questionTextBox.Text.Trim();
            if (string.IsNullOrWhiteSpace(question))
            {
                AddBotMessage("Please type a question or command first.");
                return;
            }

            AddUserMessage(question);
            questionTextBox.Clear();
            string lower = question.ToLower();

            if (_chatbot.IsActivityLogRequest(question))
            {
                AddBotMessage(BuildActivityLogSummary(false));
                _logger.Add("Activity log requested from chat");
                RefreshActivityLog();
                return;
            }

            if (_chatbot.IsShowMoreLogRequest(question))
            {
                AddBotMessage(BuildActivityLogSummary(true));
                _logger.Add("Full activity log requested from chat");
                RefreshActivityLog();
                return;
            }

            if (_chatbot.IsQuizRequest(question))
            {
                AddBotMessage("I recognised that you want to play the cybersecurity mini-game. Open the Mini Game Quiz tab and click Start Quiz.");
                _logger.Add("NLP recognised quiz request from chat");
                RefreshActivityLog();
                return;
            }

            if (_chatbot.IsTaskRequest(question))
            {
                string title = _chatbot.ExtractTaskTitle(question);
                DateTime? reminder = _chatbot.ExtractReminderDate(question);
                string description = CreateTaskDescription(title);
                var task = _taskStore.Add(title, description, reminder);
                RefreshTaskGrid(GetTaskGrid());

                string reminderText = reminder.HasValue ? $" Reminder set for {reminder.Value:yyyy-MM-dd}." : " You can add a reminder from the Task Assistant tab if needed.";
                AddBotMessage($"Task added: {task.Title}. {description}{reminderText}");
                _logger.Add($"Task added from chat using NLP: {task.Title}");
                if (reminder.HasValue)
                    _logger.Add($"Reminder set for task '{task.Title}' on {reminder.Value:yyyy-MM-dd}");
                RefreshActivityLog();
                return;
            }

            string response = _chatbot.GetResponse(question, _userName);
            AddBotMessage(response);
            _logger.Add("Chatbot responded to user input");
            RefreshActivityLog();
        }

        private string CreateTaskDescription(string title)
        {
            string lower = title.ToLower();
            if (lower.Contains("2fa") || lower.Contains("two-factor"))
                return "Enable two-factor authentication to add an extra layer of protection to your accounts.";
            if (lower.Contains("privacy"))
                return "Review account privacy settings to ensure your personal data is protected.";
            if (lower.Contains("password"))
                return "Update your password and make sure it is strong, unique, and not reused.";
            if (lower.Contains("phishing"))
                return "Check suspicious messages carefully and report phishing attempts.";
            return "Cybersecurity task added to help you stay organised and safe online.";
        }

        private void AddTaskFromForm()
        {
            string title = taskTitleTextBox.Text.Trim();
            string description = taskDescriptionTextBox.Text.Trim();
            if (string.IsNullOrWhiteSpace(title))
            {
                MessageBox.Show("Please enter a task title.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (string.IsNullOrWhiteSpace(description))
                description = CreateTaskDescription(title);

            DateTime? reminder = reminderCheckBox.Checked ? reminderPicker.Value.Date : null;
            var task = _taskStore.Add(title, description, reminder);
            taskTitleTextBox.Clear();
            taskDescriptionTextBox.Clear();
            RefreshTaskGrid(GetTaskGrid());
            _logger.Add($"Task added manually: {task.Title}");
            if (reminder.HasValue)
                _logger.Add($"Reminder set manually for task '{task.Title}' on {reminder.Value:yyyy-MM-dd}");
            RefreshActivityLog();
            MessageBox.Show("Task added successfully.", "Task Assistant", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private DataGridView GetTaskGrid()
        {
            return taskGrid;
        }

        private void RefreshTaskGrid(DataGridView taskGrid)
        {
            var rows = _taskStore.GetAll().Select(t => new { t.Id, t.Title, t.Description, Reminder = t.ReminderDisplay, Status = t.StatusDisplay, Created = t.CreatedAt.ToString("yyyy-MM-dd") }).ToList();
            taskGrid.DataSource = rows;
            if (taskGrid.Columns.Count > 0)
                taskGrid.Columns[0].Width = 30
                    ;
        }

        private int? GetSelectedTaskId()
        {
            if (taskGrid.CurrentRow == null || taskGrid.CurrentRow.Cells["Id"].Value == null)
                return null;
            if (int.TryParse(taskGrid.CurrentRow.Cells["Id"].Value.ToString(), out int id))
                return id;
            return null;
        }

        private void MarkSelectedTaskCompleted()
        {
            int? id = GetSelectedTaskId();
            if (id == null) return;
            _taskStore.MarkCompleted(id.Value);
            RefreshTaskGrid(GetTaskGrid());
            _logger.Add($"Task marked as completed: ID {id.Value}");
            RefreshActivityLog();
        }

        private void DeleteSelectedTask()
        {
            int? id = GetSelectedTaskId();
            if (id == null) return;
            if (MessageBox.Show("Delete selected task?", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                _taskStore.Delete(id.Value);
                RefreshTaskGrid(GetTaskGrid());
                _logger.Add($"Task deleted: ID {id.Value}");
                RefreshActivityLog();
            }
        }

        private void StartQuiz()
        {
            _quizEngine.Start();
            quizFeedbackBox.Clear();
            submitQuizButton.Enabled = true;
            SetQuizOptionsEnabled(true);
            LoadCurrentQuizQuestion();
            _logger.Add("Cybersecurity quiz started");
            RefreshActivityLog();
        }

        private void LoadCurrentQuizQuestion()
        {
            var q = _quizEngine.CurrentQuestion;
            if (q == null)
            {
                SetQuizOptionsEnabled(false);
                submitQuizButton.Enabled = false;
                return;
            }

            quizProgressLabel.Text = $"Question {_quizEngine.CurrentIndex + 1} of {_quizEngine.TotalQuestions} | Score: {_quizEngine.Score}";
            quizQuestionLabel.Text = q.Question;
            optionA.Text = "A) " + q.Options[0];
            optionB.Text = "B) " + q.Options[1];
            optionC.Text = q.Options.Count > 2 ? "C) " + q.Options[2] : string.Empty;
            optionD.Text = q.Options.Count > 3 ? "D) " + q.Options[3] : string.Empty;
            optionC.Visible = q.Options.Count > 2;
            optionD.Visible = q.Options.Count > 3;
            optionA.Checked = optionB.Checked = optionC.Checked = optionD.Checked = false;
        }

        private void SubmitQuizAnswer()
        {
            int selected = -1;
            if (optionA.Checked) selected = 0;
            if (optionB.Checked) selected = 1;
            if (optionC.Checked) selected = 2;
            if (optionD.Checked) selected = 3;

            if (selected == -1)
            {
                MessageBox.Show("Please select an answer first.", "Quiz", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string feedback = _quizEngine.SubmitAnswer(selected);
            quizFeedbackBox.AppendText(feedback + Environment.NewLine + Environment.NewLine);
            _logger.Add("Quiz answer submitted");

            if (_quizEngine.IsRunning)
                LoadCurrentQuizQuestion();
            else
            {
                quizProgressLabel.Text = $"Quiz complete | Final Score: {_quizEngine.Score}/{_quizEngine.TotalQuestions}";
                SetQuizOptionsEnabled(false);
                submitQuizButton.Enabled = false;
                _logger.Add($"Quiz completed with score {_quizEngine.Score}/{_quizEngine.TotalQuestions}");
            }
            RefreshActivityLog();
        }

        private void SetQuizOptionsEnabled(bool enabled)
        {
            optionA.Enabled = optionB.Enabled = optionC.Enabled = optionD.Enabled = enabled;
        }

        private void FillExample(string text)
        {
            questionTextBox.Text = text;
            questionTextBox.Focus();
            questionTextBox.SelectionStart = questionTextBox.Text.Length;
        }

        private void ClearChat()
        {
            chatBox.Clear();
            AddBotMessage("Chat cleared. You can continue asking cybersecurity questions.");
            _logger.Add("Chat cleared");
            RefreshActivityLog();
        }

        private string FormatName(string name)
        {
            if (name.Length == 0) return "Friend";
            return char.ToUpper(name[0]) + name.Substring(1).ToLower();
        }

        private void AddUserMessage(string message)
        {
            chatBox.SelectionFont = new Font("Segoe UI", 10.5F, FontStyle.Bold);
            chatBox.SelectionColor = Color.FromArgb(37, 99, 235);
            chatBox.AppendText($"{_userName}: ");
            chatBox.SelectionFont = new Font("Segoe UI", 10.5F, FontStyle.Regular);
            chatBox.SelectionColor = Color.Black;
            chatBox.AppendText(message + Environment.NewLine + Environment.NewLine);
            chatBox.ScrollToCaret();
        }

        private void AddBotMessage(string message)
        {
            chatBox.SelectionFont = new Font("Segoe UI", 10.5F, FontStyle.Bold);
            chatBox.SelectionColor = Color.FromArgb(16, 120, 80);
            chatBox.AppendText("Chatbot: ");
            chatBox.SelectionFont = new Font("Segoe UI", 10.5F, FontStyle.Regular);
            chatBox.SelectionColor = Color.Black;
            chatBox.AppendText(message + Environment.NewLine + Environment.NewLine);
            chatBox.ScrollToCaret();
        }


        private string BuildActivityLogSummary(bool showAll)
        {
            var lines = _logger.ReadAll();
            if (lines.Count == 0)
                return "No activity has been recorded yet. Try adding a task, setting a reminder, or starting the quiz.";

            var selected = showAll ? lines : lines.Skip(Math.Max(0, lines.Count - 10)).ToList();
            var response = "Here is a summary of recent actions:" + Environment.NewLine;
            int number = 1;
            foreach (string line in selected)
            {
                response += number + ". " + line + Environment.NewLine;
                number++;
            }

            if (!showAll && lines.Count > 10)
                response += Environment.NewLine + "Type 'show more' to view the full history.";

            return response.TrimEnd();
        }

        private void RefreshActivityLog()
        {
            if (activityLogBox == null) return;
            activityLogBox.Clear();
            foreach (string line in _logger.ReadAll())
                activityLogBox.AppendText(line + Environment.NewLine);
        }
    }
}
